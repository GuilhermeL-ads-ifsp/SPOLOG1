#include <stdio.h>

int main() {
    int v[20];
    int i, soma = 0;

    for (i = 0; i < 20; i++) {
        printf("Digite o %dº numero: ", i + 1);
        scanf("%d", &v[i]);
    }

    for (i = 0; i < 10; i++) {
        soma += v[i];
    }

    printf("\nSoma dos 10 primeiros elementos = %d\n", soma);

    return 0;
}