#include <stdio.h>

int main() {
    int v[15];
    int i;

    for (i = 0; i < 15; i++) {
        printf("Digite o %d° numero: ", i + 1);
        scanf("%d", &v[i]);
    }

    printf("\nValores maiores ou iguais a 10:\n");
    for (i = 0; i < 15; i++) {
        if (v[i] >= 10) {
            printf("%d ", v[i]);
        }
    }

    printf("\n");
    return 0;
}