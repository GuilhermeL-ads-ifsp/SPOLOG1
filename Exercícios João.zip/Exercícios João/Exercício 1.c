#include <stdio.h>

int main() {
    int v[10];
    int i;

    for (i = 0; i < 10; i++) {
        printf("Digite o %dº valor: ", i + 1);
        scanf("%d", &v[i]);
    }

    printf("\nValores lidos:\n");
    for (i = 0; i < 10; i++) {
        printf("v[%d] = %d\n", i, v[i]);
    }

    return 0;
}