#include <stdio.h>

int main() {
    int v[10], invertido[10];
    int i;

    for (i = 0; i < 10; i++) {
        printf("Digite v[%d]: ", i);
        scanf("%d", &v[i]);
    }

    for (i = 0; i < 10; i++) {
        invertido[i] = v[9 - i];
    }

    printf("\nVetor original:\n");
    for (i = 0; i < 10; i++) {
        printf("%d ", v[i]);
    }

    printf("\n\nVetor invertido:\n");
    for (i = 0; i < 10; i++) {
        printf("%d ", invertido[i]);
    }

    printf("\n");
    return 0;
}