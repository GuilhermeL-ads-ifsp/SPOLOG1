#include <stdio.h>

int main() {
    int v[10];
    int A, B, C;
    int i;
    int contA = 0, contB = 0, contC = 0;

    for (i = 0; i < 10; i++) {
        printf("Digite v[%d]: ", i);
        scanf("%d", &v[i]);
    }

    printf("Digite o valor de A: ");
    scanf("%d", &A);

    printf("Digite o valor de B: ");
    scanf("%d", &B);

    printf("Digite o valor de C: ");
    scanf("%d", &C);
    for (i = 0; i < 10; i++) {
        if (v[i] == A) contA++;
        if (v[i] == B) contB++;
        if (v[i] == C) contC++;
    }
    printf("\nO numero %d apareceu %d vez(es).\n", A, contA);
    printf("O numero %d apareceu %d vez(es).\n", B, contB);
    printf("O numero %d apareceu %d vez(es).\n", C, contC);

    return 0;
}