#include <stdio.h>

int main() {
    int A[8], B[8];
    int i;

    for (i = 0; i < 8; i++) {
        printf("Digite A[%d]: ", i);
        scanf("%d", &A[i]);
        B[i] = A[i] * 3;
    }

    printf("\nValores do vetor B:\n");
    for (i = 0; i < 8; i++) {
        printf("B[%d] = %d\n", i, B[i]);
    }

    return 0;
}