#include <stdio.h>

int main() {
    int v[30];
    int i, menor, maior, quantidadeAcimaMedia = 0;
    int soma = 0;
    float media;

    for (i = 0; i < 30; i++) {
        printf("Digite o valor %d: ", i + 1);
        scanf("%d", &v[i]);
        soma += v[i];

        if (i == 0) {
            menor = v[i];
            maior = v[i];
        } else {
            if (v[i] < menor) {
                menor = v[i];
            }
            if (v[i] > maior) {
                maior = v[i];
            }
        }
    }

    media = soma / 30.0;

    printf("\nNumeros pares do vetor:\n");
    for (i = 0; i < 30; i++) {
        if (v[i] % 2 == 0) {
            printf("%d ", v[i]);
        }
    }

    for (i = 0; i < 30; i++) {
        if (v[i] > media) {
            quantidadeAcimaMedia++;
        }
    }

    printf("\n\nMenor valor: %d\n", menor);
    printf("Maior valor: %d\n", maior);
    printf("Media dos valores: %.2f\n", media);
    printf("Quantidade de valores maiores que a media: %d\n", quantidadeAcimaMedia);

    return 0;
}